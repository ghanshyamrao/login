﻿# Hello World! 🌍

## THE PROJECT: Trafic light mini-game | HTML, CSS, JS

Subjects: JavaScript - Objects | setInterval | clearInterval | event.target |  addEventListner 

> EN - This was a study about some JS techniques as uses of objects and time control. 
>
> PT - Estudo sobre algumas tecnicas em JS como o uso de objetos e controle de tempo.
>
> IT - Studio sulle tecniche in JS come l'utilizzo di oggetti e controlo del tempo.

✔ This code uses:


![HTML](https://img.shields.io/badge/-HTML-E34F26?style=plastic&logo=html5&logoColor=FFFFFF) ![CSS](https://img.shields.io/badge/-CSS-1572B6?style=plastic&logo=css3&logoColor=FFFFFF) ![JS](https://img.shields.io/badge/JavaScript-F7DF1E?style=plastic&logo=javascript&logoColor=FFFFFF)

⚠ Code lang: EN

---

☞ ABOUT ME ☜

✔ My knowledges:

⮞ HTML5

▶ CSS ➠ -@Media Queries -Flexbox -Grid -Keyframes/Animation -Selectors

▶ JavaScript ➠ -Functions - Objects - Colections - Arrays - Loops if/while/forEach/forOf/forIn - Console - jQuery

▶ Wordpress➠ -Instalation / SetUp / Control pannel - User Management - Plugin Management - Custom Fields - PHP for WP basics - Child theme

---

✔ My places:

[CodePen](https://codepen.io/Wagner3UB) | [GitHub](https://github.com/Wagner3UB/) | [Linkedin profile](https://www.linkedin.com/in/wagner-trezub/) | [Behance](https://www.behance.net/trezub/)

✔ For any questions, please contact me: <trezub.w@gmail.com>

⁑ Bye Bye and keep coding ⁑

⁑ Wagner Trezub ⁑

